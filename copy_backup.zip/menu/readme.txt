1. Copy file backup.sh in folder server script to linux / unix server
2. Changes source path inside the copyApp.cmd
3. run main_menu.cmd