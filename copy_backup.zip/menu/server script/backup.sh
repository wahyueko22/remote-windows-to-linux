zip -r9 "/home/administrator/test.zip"  "/home/administrator/Music"
